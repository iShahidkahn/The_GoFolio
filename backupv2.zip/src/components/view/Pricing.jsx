import React from 'react'
import Pakages from '../pages/pricing/Pakages'

const Pricing = () => {
    return (
        <>
            <Pakages />
        </>
    )
}

export default Pricing