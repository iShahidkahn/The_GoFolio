import React from 'react';
import dropArrow from '../../../dist/icons/dropdown_arrowx2.svg'

const Nav = () => {
  return (
    <nav className="navbar navbar-expand-lg">
      <div className="container-fluid px-0" style={{ height: '70px' }}>
        {/* <button type="button" id="sidebarCollapse" className="btn btn-primary">
        <i className="fa fa-bars" />
        <span className="sr-only">Toggle Menu</span>
      </button> */}
        <span className='heading'>
          Compare Portfolios
        </span>
        <button
          className="btn btn-dark d-inline-block d-lg-none ml-auto"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i className="fa fa-bars" />
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="nav navbar-nav ms-auto" style={{ height: '30px' }}>
            <li className="nav-item">
              <span class="position-relative">
                <i class="fa-solid fa-bell"></i>
                <span class="position-absolute top-0 start-100 translate-middle bg-danger border border-light rounded-circle">
                </span>
              </span>
              <span style={{ marginLeft: "10px" }}>Benjamin Treece</span>
            </li>
            <li className="nav-item">
              <span className="nav-link B">
                <p>B</p>
              </span>
            </li>
            <div class="btn-group">
              <span class="dropdown-toggle nav-link" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
                <img src={dropArrow}  />
              </span>
              <ul class="dropdown-menu dropdown-menu-lg-end mt-2 me-1">
                <li><button class="dropdown-item" type="button">Profile</button></li>
                <li><button class="dropdown-item" type="button">Account Setting</button></li>
                <li><button class="dropdown-item" type="button">Logout</button></li>
              </ul>
            </div>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Nav