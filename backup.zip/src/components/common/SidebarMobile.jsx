import React from 'react'

const SidebarMobile = () => {
  return (
    <div>SidebarMobile</div>
  )
}

export default SidebarMobile