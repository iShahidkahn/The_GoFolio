import React from 'react'
import AllPosts from '../pages/blog/AllPosts'

const Blog = () => {
  return (
    <>
    <AllPosts/>
    </>
  )
}

export default Blog