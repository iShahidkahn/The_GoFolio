import React from 'react'

const BlogCa = () => {
  return (
    <div>BlogCa</div>
  )
}

export default BlogCa